
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lukejgaskell',
  applicationName: 'represent',
  appUid: 'NfqPsPz3cMqgGGLG0Q',
  orgUid: 'd1f7b0b2-1180-4d43-84da-89d8613514c3',
  deploymentUid: '94279205-0c5c-4391-ad2b-5a9598132cb6',
  serviceName: 'backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'backend-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}